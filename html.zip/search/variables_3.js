var searchData=
[
  ['lista_0',['lista',['../struct__iterador.html#a2867a1600369e498dcd9b42a04f8f495',1,'_iterador']]]
];
