var searchData=
[
  ['proximo_0',['proximo',['../struct__node.html#a2e4495102d9f71fcc7fd7969caa9073f',1,'_node']]]
];
