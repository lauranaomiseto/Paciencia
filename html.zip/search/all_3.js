var searchData=
[
  ['data_0',['data',['../struct__node.html#aa3ff051a47d9e18487e7b819852521c5',1,'_node']]]
];
