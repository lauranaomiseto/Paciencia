var searchData=
[
  ['aleatoriza_0',['aleatoriza',['../main_8c.html#a9f52b364ef492ba108092737b968a90b',1,'main.c']]],
  ['anterior_1',['anterior',['../struct__node.html#ac475813031b494727671e927146cefc3',1,'_node']]]
];
