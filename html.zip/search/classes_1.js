var searchData=
[
  ['pilha_0',['Pilha',['../struct_pilha.html',1,'']]]
];
