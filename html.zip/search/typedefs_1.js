var searchData=
[
  ['lista_0',['Lista',['../lista_8h.html#a5015eb50c0ff1f8e65c9f5942e2c8410',1,'lista.h']]]
];
