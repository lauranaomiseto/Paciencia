var searchData=
[
  ['iterador_0',['Iterador',['../lista_8h.html#a846f139878e3e4cc85b4d611ace8f9e7',1,'lista.h']]]
];
