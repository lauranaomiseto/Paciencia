var searchData=
[
  ['listaappend_0',['listaAppend',['../lista_8c.html#a1af9bfc4b8351e0e9ce7142e7ef992d3',1,'listaAppend(Lista *lista1, Lista *lista2):&#160;lista.c'],['../lista_8h.html#a1af9bfc4b8351e0e9ce7142e7ef992d3',1,'listaAppend(Lista *lista1, Lista *lista2):&#160;lista.c']]],
  ['listadestruir_1',['listaDestruir',['../lista_8c.html#aaa366dc6a104cc631cec1feb23bd5720',1,'listaDestruir(Lista *lista):&#160;lista.c'],['../lista_8h.html#aac9c3a3f8dffdc674068e685f402ac51',1,'listaDestruir(Lista *):&#160;lista.c']]],
  ['listainicializar_2',['listaInicializar',['../lista_8c.html#a01590ece560609f70b0915821f6c9bda',1,'listaInicializar(Lista *lista):&#160;lista.c'],['../lista_8h.html#aca8f7af00ca796362532a93093f6dc42',1,'listaInicializar(Lista *):&#160;lista.c']]],
  ['listainserirfim_3',['listaInserirFim',['../lista_8c.html#a8dfa711348c8d5b3b0f021d30a325c93',1,'listaInserirFim(Lista *lista, T dado):&#160;lista.c'],['../lista_8h.html#acdf503d123a5da3387c6d5972437f9ee',1,'listaInserirFim(Lista *, T):&#160;lista.c']]],
  ['listainseririnicio_4',['listaInserirInicio',['../lista_8c.html#aa450e21d1c689fcbbaeae4e23aaeb1d7',1,'listaInserirInicio(Lista *lista, T dado):&#160;lista.c'],['../lista_8h.html#a676e314bcb981fbd42b5a9b5a229b333',1,'listaInserirInicio(Lista *, T):&#160;lista.c']]],
  ['listaquantidade_5',['listaQuantidade',['../lista_8c.html#a1c3e273fe5c1a20b8b2f931af276d76a',1,'listaQuantidade(Lista *lista):&#160;lista.c'],['../lista_8h.html#a6514a80b3ff29536cd9e4731fdda9373',1,'listaQuantidade(Lista *):&#160;lista.c']]],
  ['listaremoverelemento_6',['listaRemoverElemento',['../lista_8c.html#a252632ae82165aa9dc5d1b1373fcd9a1',1,'listaRemoverElemento(Iterador i):&#160;lista.c'],['../lista_8h.html#ac43f4163ac613d3119d70749564f4b68',1,'listaRemoverElemento(Iterador):&#160;lista.c']]],
  ['listasplit_7',['listaSplit',['../lista_8c.html#a686a722adabf054b788e8cccbb5b3560',1,'listaSplit(Iterador i, Lista *lista):&#160;lista.c'],['../lista_8h.html#a8ec8c320e28d857585e78895807cd37f',1,'listaSplit(Iterador, Lista *):&#160;lista.c']]]
];
