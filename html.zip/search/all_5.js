var searchData=
[
  ['inicializajogo_0',['inicializaJogo',['../jogo_8c.html#a68552fe537be2a57a9213ef1f4ed3dd4',1,'inicializaJogo(Lista fileiras[], Pilha *virada, Pilha *visivel, Pilha finais[]):&#160;jogo.c'],['../jogo_8h.html#a68552fe537be2a57a9213ef1f4ed3dd4',1,'inicializaJogo(Lista fileiras[], Pilha *virada, Pilha *visivel, Pilha finais[]):&#160;jogo.c']]],
  ['inserepilhaf_1',['inserePilhaF',['../jogo_8c.html#a61d2956f17dde9e575cd813e80435698',1,'inserePilhaF(Pilha *pilha, T carta):&#160;jogo.c'],['../jogo_8h.html#a61d2956f17dde9e575cd813e80435698',1,'inserePilhaF(Pilha *pilha, T carta):&#160;jogo.c']]],
  ['iterador_2',['Iterador',['../lista_8h.html#a846f139878e3e4cc85b4d611ace8f9e7',1,'lista.h']]],
  ['iteradoranterior_3',['iteradorAnterior',['../lista_8c.html#a1bdcb379a23dd88060df1c7299423762',1,'iteradorAnterior(Iterador i):&#160;lista.c'],['../lista_8h.html#a82d9166923d52e5a0ee42cd3045201c0',1,'iteradorAnterior(Iterador):&#160;lista.c']]],
  ['iteradorelemento_4',['iteradorElemento',['../lista_8c.html#afc9369da5ada695e64a2a750d8c27782',1,'iteradorElemento(Iterador i):&#160;lista.c'],['../lista_8h.html#a7922a0df8151339e025f4fde51ba654a',1,'iteradorElemento(Iterador):&#160;lista.c']]],
  ['iteradorprimeiro_5',['iteradorPrimeiro',['../lista_8c.html#a706166351f9d51a3f395fc4b8693db30',1,'iteradorPrimeiro(Lista *lista):&#160;lista.c'],['../lista_8h.html#a6ac74f20e115a8b30e414b1d4c8847a1',1,'iteradorPrimeiro(Lista *):&#160;lista.c']]],
  ['iteradorprocura_6',['iteradorProcura',['../lista_8c.html#ab9ec8bd0cfcbe16e10d4231d8926fcad',1,'iteradorProcura(Lista *lista, T dado):&#160;lista.c'],['../lista_8h.html#a71a2083ed6c161ae131a0c607eddf38e',1,'iteradorProcura(Lista *, T):&#160;lista.c']]],
  ['iteradorproximo_7',['iteradorProximo',['../lista_8c.html#a7d06981f25383a027cd779466f994ab8',1,'iteradorProximo(Iterador i):&#160;lista.c'],['../lista_8h.html#a9eabdfec8e2124ffa22f603f60f3f92a',1,'iteradorProximo(Iterador):&#160;lista.c']]],
  ['iteradorultimo_8',['iteradorUltimo',['../lista_8c.html#a7b3e4d2368053925467b3a0aa851b491',1,'iteradorUltimo(Lista *lista):&#160;lista.c'],['../lista_8h.html#ad39d079fe8d6fe5eb89ad0742eb18578',1,'iteradorUltimo(Lista *):&#160;lista.c']]],
  ['iteradorvalido_9',['iteradorValido',['../lista_8c.html#a23e26a862ef9b73a39dfe22939b1eeb6',1,'iteradorValido(Iterador i):&#160;lista.c'],['../lista_8h.html#a48a9f3daaa6d12b2919a923cced76105',1,'iteradorValido(Iterador):&#160;lista.c']]]
];
