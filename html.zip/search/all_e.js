var searchData=
[
  ['valor_0',['valor',['../struct__carta.html#a83201786792501b53e667771949a8129',1,'_carta']]],
  ['visivel_1',['visivel',['../struct__carta.html#ac6b8bd40712228faf33f1408bd38c8ef',1,'_carta']]]
];
